import React from 'react'
import {render} from 'react-dom'
import App from './components/App'
import Note from './components/Note'








render(<App />, document.getElementById('grid'))
//render(<Note note={notes[0]}/>, document.getElementById('note'))